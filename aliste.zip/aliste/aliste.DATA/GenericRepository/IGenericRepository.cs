﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.DATA.GenericRepository
{
    public interface IGenericRepository<TEntity> where TEntity : class
    {
        void Delete(TEntity entity);
        TEntity Find(int id);
        IQueryable<TEntity> GetAll();
        void Insert(TEntity entity);
        void Update(TEntity entity);
    }
}
