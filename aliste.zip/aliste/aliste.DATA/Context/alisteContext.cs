﻿using aliste.CORE.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.DATA.Context
{
    public partial class alisteContext : DbContext
    {
        public alisteContext() : base("name=alisteDBEntities")
        {
            Configuration.LazyLoadingEnabled = false;
        }

        public virtual DbSet<Admin> Admin { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<Product> Product { get; set; }
        public virtual DbSet<CORE.Entities.Type> Type { get; set; }
        public virtual DbSet<Motor> Motor { get; set; }
        public virtual DbSet<Brand> Brand { get; set; }
        public virtual DbSet<Category> Category { get; set; }
        public virtual DbSet<Fuel> Fuel { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>().ToTable("Admin", "dbo");
            modelBuilder.Entity<User>().ToTable("User", "dbo");
            modelBuilder.Entity<Category>().ToTable("Category", "dbo");
            modelBuilder.Entity<Fuel>().ToTable("Fuel", "dbo");
            modelBuilder.Entity<CORE.Entities.Type>().ToTable("Type", "dbo");
            modelBuilder.Entity<Motor>().ToTable("Motor", "dbo");
            modelBuilder.Entity<Brand>().ToTable("Brand", "dbo");
            modelBuilder.Entity<Product>().ToTable("Product", "dbo");
            base.OnModelCreating(modelBuilder);
        }



    }
}
