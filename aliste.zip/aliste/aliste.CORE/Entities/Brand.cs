﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.CORE.Entities
{
    public partial class Brand : Base
    {
        public string BrandName { get; set; }
    }
}
