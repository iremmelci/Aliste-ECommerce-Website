﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.CORE.Entities
{
    public partial class Fuel : Base
    {
        public string FuelType { get; set; }

    }
}
