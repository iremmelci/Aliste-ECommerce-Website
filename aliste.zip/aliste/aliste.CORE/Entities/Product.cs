﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.CORE.Entities
{
    public partial class Product : Base
    {
        public int CategoryID { get; set; }
        public int MotorID { get; set; }
        public int TypeID { get; set; }
        public int BrandID { get; set; }
        public int FuelID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Color { get; set; }
        public string ShiftType { get; set; }
        public DateTime ProductionDate { get; set; }
        public double MaxPrice { get; set; }
        public double MinPrice { get; set; }

    }
}
