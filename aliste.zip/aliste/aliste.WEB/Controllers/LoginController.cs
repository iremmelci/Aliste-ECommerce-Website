﻿using aliste.DATA.UnitofWork;
using aliste.DTO.EEntity;
using aliste.SERVICES.Interface;
using aliste.SERVICES.Services;
using aliste.UTILITIES.SessionOperations;
using System.Web.Mvc;
using System.Web.Security;

namespace aliste.WEB.Controllers
{
    public class LoginController : BaseController
    {
        // GET: Login
        public ActionResult Index() { return View(); }
        private readonly IUserService _userService;
        private readonly IUnitofWork _uow;
        private SessionContext _sessionContext;

        public LoginController(IUnitofWork uow, IUserService userService) : base(uow)
        {
            _uow = uow;
            _userService = userService;
            _sessionContext = new SessionContext();

        }

        [HttpPost]
        public ActionResult LoginControl(ELoginDTO login)
        {
            var result = _userService.GetUserByUnPass(login.UserName, login.Password);
            if (result != null && result.ID != 0)
            {
                AutoMapper.Mapper.DynamicMap(result, _sessionContext);
                Session["SessionContext"] = _sessionContext;
                FormsAuthentication.SetAuthCookie($"{_sessionContext.UserName},{_sessionContext.ID}", true);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                Response.Redirect("/Login/Index");
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }



    }
}