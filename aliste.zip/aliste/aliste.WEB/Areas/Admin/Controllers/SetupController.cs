﻿using aliste.DATA.UnitofWork;
using aliste.DTO.EEntity;
using aliste.SERVICES.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace aliste.WEB.Areas.Admin.Controllers
{
    public class SetupController : AdminBaseController
    {
        private readonly IUnitofWork _uow;
        private readonly ISetupService _setupService;

        public SetupController(IUnitofWork uow, ISetupService setupService) : base(uow)
        {
            _uow = uow;
            _setupService = setupService;
        }


        //--------------Motor İşlemleri--------------------------//
        public ActionResult MotorInsert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult MotorInsert(EMotorDTO motor)
        {
            if (ModelState.IsValid)
            {
                _setupService.MotorInsert(motor);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult MotorIndex()
        {

            return View();
        }

        public ActionResult motorliste()
        {
            return Json(_setupService.GetAllMotor(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult MotorUpdate(int ID)
        {
            var bulunan = _setupService.MotorBul((int)ID);
            return View(bulunan);
        }

        [HttpPost]
        public ActionResult MotorUpdate(EMotorDTO gelen)
        {
            _setupService.MotorUpdate(gelen);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        //--------------------------Marka işlemleri-----------------//////////
        public ActionResult BrandIndex()
        {
            return View();
        }
        public ActionResult brandListe()
        {
            return Json(_setupService.GetAllBrand(), JsonRequestBehavior.AllowGet);
        }
        public ActionResult BrandInsert()
        {
            return View();
        }
        [HttpPost]
        public ActionResult BrandInsert(EBrandDTO brand)
        {
            if (ModelState.IsValid)
            {
                _setupService.BrandInsert(brand);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult BrandUpdate(int? ID)
        {
            var bulunan = _setupService.BrandBul((int)ID);
            return View(bulunan);
        }
        [HttpPost]
        public ActionResult BrandUpdate(EBrandDTO gelen)
        {
            _setupService.BrandUpdate(gelen);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        //--------------------------Yakıt tipi işlemleri------------------------------//
        public ActionResult FuelIndex()
        {
            return View();
        }
        public ActionResult fuelgetall()
        {
            return Json(_setupService.GetAllFuel(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult FuelUpdate(int? ID)
        {
            
            if (ID != 0 && ID != null)
            {
                return View(_setupService.FuelBul((int)ID));
            }
            else
            {
                return Redirect("/Admin/Shared/HataSayfa");
            }

        }
        [HttpPost]
        public ActionResult FuelUpdate(EFuelDTO gelen)
        {
            _setupService.FuelUpdate(gelen);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        //---------------------kategori işlemleri--------------------//
        public ActionResult CategoryIndex()
        {
            return View();
        }

        public ActionResult categorygetall()
        {
            return Json(_setupService.KategoriListele(),JsonRequestBehavior.AllowGet);
        }
        public ActionResult CategoryInsert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CategoryInsert(ECategoryDTO gelen)
        {
            if (ModelState.IsValid)
            {
                _setupService.KategoriEkle(gelen);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }


    }
}