﻿using aliste.DATA.UnitofWork;
using aliste.SERVICES.Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace aliste.WEB.Areas.Admin.Controllers
{
    public class ProductController : AdminBaseController
    {
        private readonly IUnitofWork _uow;
        private readonly ISetupService _setupService;
        private readonly IProductService _productService;

        public ProductController(IUnitofWork uow,ISetupService setupService,IProductService productService) : base(uow)
        {
            _uow = uow;
            _setupService = setupService;
            _productService = productService;
        }

        // GET: Admin/Product
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult urunlistele()
        {
            return Json(_productService.UrunListele(),JsonRequestBehavior.AllowGet);
        }

        public ActionResult ProductInsert()
        {
            ViewBag.cat = _setupService.KategoriListele();
            ViewBag.fuel = _setupService.GetAllFuel();
            ViewBag.mot = _setupService.GetAllMotor();
            ViewBag.bra = _setupService.GetAllBrand();
            return View();
        }

        [HttpPost]
        public ActionResult TempImage(HttpPostedFileBase tempres)
        {
            using (BinaryReader reader = new BinaryReader(tempres.InputStream))
            {
                Session["TempImage"] = reader.ReadBytes((Int32)tempres.ContentLength);
            }
            return Json("", JsonRequestBehavior.AllowGet);
        }
        public ActionResult TempImageShow(HttpPostedFileBase tempres)
        {
            
            return new FileContentResult((byte[])Session["TempImage"],"image/*");
        }
    }
}