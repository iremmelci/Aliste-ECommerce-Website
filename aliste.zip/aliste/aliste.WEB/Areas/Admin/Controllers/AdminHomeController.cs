﻿using aliste.DATA.UnitofWork;
using aliste.SERVICES.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace aliste.WEB.Areas.Admin.Controllers
{
    public class AdminHomeController : AdminBaseController
    {
        private readonly IUnitofWork _uow;
        private readonly ICarService _carService;

        public AdminHomeController( IUnitofWork uow, ICarService carService) : base(uow)
        {
            _uow = uow;
            _carService = carService;
        }

        // GET: Admin/AdminHome
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult allcar()
        {
            return Json(_carService.GetAllProduct(),JsonRequestBehavior.AllowGet);
        }
    }
}