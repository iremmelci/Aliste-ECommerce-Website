/*=========================================================================================
	File Name: compact-menu.js
	Description: Compact menu page level only
	----------------------------------------------------------------------------------------
	Item Name: Modern Admin - Clean Bootstrap 4 Dashboard HTML Template
	Version: 1.0
	Author: Pixinvent
	Author URL: hhttp://www.themeforest.net/user/pixinvent
==========================================================================================*/
$(document).ready(function(){
	setTimeout(function(){
		$.app.menu.collapse();
	}, 100);
});