﻿function errorMes(message, errorTitle) {
    toastr.error(message, errorTitle, toastr.options = {
        "closeButton": true,
        "debug": true,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "1000",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"

    })
};
function succMes(message, sucTitle) {
    toastr.success(message, sucTitle, toastr.options = {
        "closeButton": true,
        "debug": true,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "1000",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"

    })
};

function warMes(message, warTitle) {
    toastr.warning(message, warTitle, toastr.options = {
        "closeButton": true,
        "debug": true,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "1000",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"

    })
};


$(document).ready(
    function AracListele() {
        $.ajax({
            url: "/Admin/AdminHome/allcar",
            type: "get",
            success: function (data) {
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + data[i].Title + '</td>' +
                        '<td>' + data[i].Age + '</td>' +
                        '<td>' + data[i].Color + '</td>' +
                        '<td>' + data[i].MaxPrice + '</td>' +
                        '<td>' + data[i].MinPrice + '</td>' +
                        '<td>' + data[i].BrandName + '</td>' +
                        '<td>' + data[i].FuelType + '</td>' +
                        '</tr>'
                }
                $("#tumaraclar").html(html);
            }
        });
    }
)

//-----------------------Motor işlemleri----------------------//
function MotorEkle() {
    if ($("#inputMotor").val() != null && $("#inputMotor").val() != "") {
        var data = {
            MotorType: $("#inputMotor").val(),
        };
        $.ajax({

            url: "/Admin/Setup/MotorInsert",
            type: "post",
            data: data,
            success: function (e) {
                if (e == true) {
                    succMes("Kayıt Başarılı", "İşlem Başarılı")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/MotorIndex")
                    }, 1500)
                }
                else {
                    errorMes("Kayıt Başarısız", "İşlem Başarısız")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/MotorIndex")
                    }, 1500)
                }
            }
        });
    }
}

$(document).ready(
    function MotorListele() {
        $.ajax({
            url: "/Admin/Setup/motorliste",
            type: "get",
            success: function (data) {
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + data[i].ID + '</td>' +
                        '<td>' + data[i].MotorType + '</td>' +
                        '<td>' + '<a class="btn btn-warning" href="/Admin/Setup/MotorUpdate/' + data[i].ID + '">' +
                        '<i class="la la-edit"></i> Güncelle</a>' + ' </td > ' +
                        '</tr>'
                }
                $("#tummotor").html(html);
            }
        });
    }
)

function MotorGuncelle() {
    if ($("#inputMotor").val() != null && $("#inputMotor").val() != "") {
        var data = {
            MotorType: $("#inputMotor").val(),
            ID: $("#inputID").val(),
        };
        $.ajax({

            url: "/Admin/Setup/MotorUpdate",
            type: "post",
            data: data,
            success: function (e) {
                if (e == true) {
                    succMes("Kayıt Başarılı", "İşlem Başarılı")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/MotorIndex")
                    }, 1500)
                }
                else {
                    errorMes("Kayıt Başarısız", "İşlem Başarısız")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/MotorIndex")
                    }, 1500)
                }
            }
        });
    }
}

//---------------------Marka işlemleri-----------------------//
function BrandEkle() {
    if ($("#inputBrand").val() != null && $("#inputBrand").val() != "") {
        var data = {
            BrandName: $("#inputBrand").val(),
        };
        $.ajax({

            url: "/Admin/Setup/BrandInsert",
            type: "post",
            data: data,
            success: function (e) {
                if (e == true) {
                    succMes("Kayıt Başarılı", "İşlem Başarılı")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/BrandIndex")
                    }, 1500)
                }
                else {
                    errorMes("Kayıt Başarısız", "İşlem Başarısız")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/BrandIndex")
                    }, 1500)
                }
            }
        });
    }
}

$(document).ready(
    function BrandListele() {
        $.ajax({
            url: "/Admin/Setup/brandListe",
            type: "get",
            success: function (data) {
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + data[i].ID + '</td>' +
                        '<td>' + data[i].BrandName + '</td>' +
                        '<td>' + '<a class="btn btn-warning" href="/Admin/Setup/BrandUpdate/' + data[i].ID + '">' +
                        '<i class="la la-edit"></i> Güncelle</a>' + ' </td > ' +
                        '</tr>'
                }
                $("#tummarka").html(html);
            }
        });
    }
)
function BrandGuncelle() {
    if ($("#inputBrand").val() != null && $("#inputBrand").val() != "") {
        var data = {
            BrandName: $("#inputBrand").val(),
            ID: $("#inputID").val(),
        };
        $.ajax({

            url: "/Admin/Setup/BrandUpdate",
            type: "post",
            data: data,
            success: function (e) {
                if (e == true) {
                    succMes("Kayıt Başarılı", "İşlem Başarılı")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/BrandIndex")
                    }, 1500)
                }
                else {
                    errorMes("Kayıt Başarısız", "İşlem Başarısız")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/BrandIndex")
                    }, 1500)
                }
            }
        });
    }
}
//////////// .......................yakıt işlemleri.................////////////////////////
$(document).ready(
    function FuelListele() {
        $.ajax({
            url: "/Admin/Setup/fuelgetall",
            type: "get",
            success: function (data) {
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + data[i].ID + '</td>' +
                        '<td>' + data[i].FuelType + '</td>' +
                        '<td>' + '<a class="btn btn-warning" href="/Admin/Setup/FuelUpdate/' + data[i].ID + '">' +
                        '<i class="la la-edit"></i> Güncelle</a>' + ' </td > ' +
                        '</tr>'
                }
                $("#tumyakit").html(html);
            }
        });
    }
)
function FuelGuncelle() {
    if ($("#inputFuel").val() != null && $("#inputFuel").val() != "") {
        var data = {
            FuelType: $("#inputFuel").val(),
            ID: $("#inputID").val(),
        };
        $.ajax({

            url: "/Admin/Setup/FuelUpdate",
            type: "post",
            data: data,
            success: function (e) {
                if (e == true) {
                    succMes("Kayıt Başarılı", "İşlem Başarılı")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/FuelIndex")
                    }, 1500)
                }
                else {
                    errorMes("Kayıt Başarısız", "İşlem Başarısız")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/FuelIndex")
                    }, 1500)
                }
            }
        });
    }
}
//--------------kategori işlemleri-------------------//
$(document).ready(
    function KategoriListele() {
        $.ajax({
            url: "/Admin/Setup/categorygetall",
            type: "get",
            success: function (data) {
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + data[i].ID + '</td>' +
                        '<td>' + data[i].CategoryName + '</td>' +
                        '<td>' + '<a class="btn btn-warning btn-sm" href="/Admin/Setup/CategoryUpdate/' + data[i].ID + '">' +
                        '<i class="la la-edit"></i> Güncelle</a>' + ' </td > ' +
                        '</tr>'
                }
                $("#tumkategori").html(html);
            }
        });
    }
)
function KategoriEkle() {
    if ($("#inputCategoryName").val() != null && $("#inputCategoryName").val() != "") {
        var data = {
            CategoryName: $("#inputCategoryName").val(),
        };
        $.ajax({

            url: "/Admin/Setup/CategoryInsert",
            type: "post",
            data: data,
            success: function (e) {
                if (e == true) {
                    succMes("Kayıt Başarılı", "İşlem Başarılı")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/CategoryIndex")
                    }, 1500)
                }
                else {
                    errorMes("Kayıt Başarısız", "İşlem Başarısız")
                    setInterval(function () {
                        window.location.replace("/Admin/Setup/CategoryIndex")
                    }, 1500)
                }
            }
        });
    }
}


$(document).ready(
    function tumAraclar() {
        $.ajax({
            url: "/Admin/Product/urunlistele",
            type: "get",
            success: function (data) {
                var html = '';
                for (var i = 0; i < data.length; i++) {
                    html += '<tr>' +
                        '<td>' + data[i].Title + '</td>' +
                        '<td>' + data[i].Age + '</td>' +
                        '<td>' + data[i].Color + '</td>' +
                        '<td>' + data[i].MaxPrice + '</td>' +
                        '<td>' + data[i].MinPrice + '</td>' +
                        '<td>' + data[i].BrandName + '</td>' +
                        '<td>' + data[i].FuelType + '</td>' +
                        '</tr>'
                }
                $("#tumaraclar").html(html);
            }
        });
    }
)



