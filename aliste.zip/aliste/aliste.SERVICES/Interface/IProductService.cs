﻿using aliste.DTO.EEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.SERVICES.Interface
{
    public interface IProductService
    {
        List<EProductListDTO> UrunListele();
    }
}
