﻿using aliste.DTO.EEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.SERVICES.Interface
{
    public interface ISetupService
    {
        void MotorInsert(EMotorDTO gelen);
        List<EMotorDTO> GetAllMotor();
        EMotorDTO MotorBul(int ID);
        void MotorUpdate(EMotorDTO gelen);
        void BrandInsert(EBrandDTO gelen);
        List<EBrandDTO> GetAllBrand();
        EBrandDTO BrandBul(int ID);
        void BrandUpdate(EBrandDTO gelen);
        List<EFuelDTO> GetAllFuel();
        EFuelDTO FuelBul(int? ID);
        void FuelUpdate(EFuelDTO gelen);
        List<ECategoryDTO> KategoriListele();
        void KategoriEkle(ECategoryDTO gelen);

     }
}
