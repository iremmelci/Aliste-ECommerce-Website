﻿using aliste.CORE.Entities;
using aliste.DATA.GenericRepository;
using aliste.DATA.UnitofWork;
using aliste.DTO.EEntity;
using aliste.SERVICES.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.SERVICES.Services
{
    public class UserService : IUserService
    {
        private readonly IGenericRepository<User> _userRepository;
        private readonly IUnitofWork _uow;

        public UserService(UnitofWork uow)
        {
            _uow = uow;
            _userRepository = _uow.GetRepository<User>();
        }

        public EUserDTO GetUserByUnPass(string username, string password)
        {
            var control = (from u in _userRepository.GetAll()
                           where u.UserName == username && u.Password == password
                           select new EUserDTO
                           {
                               ID = u.ID,
                               UserName = u.UserName
                           }).SingleOrDefault();
            return control;
        }

    }


}