﻿using aliste.CORE.Entities;
using aliste.DATA.GenericRepository;
using aliste.DATA.UnitofWork;
using aliste.DTO.EEntity;
using aliste.SERVICES.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.SERVICES.Services
{
    public class SetupService : ISetupService
    {
        private readonly IGenericRepository<Motor> _motorRepository;
        private readonly IGenericRepository<Brand> _brandRepository;
        private readonly IGenericRepository<Fuel> _fuelRepository;
        private readonly IGenericRepository<Category> _categoryRepository;
        private readonly IUnitofWork _uow;
        private EMotorDTO _motorDTO;
        private EBrandDTO _brandDTO;
        private EFuelDTO _fuelDTO;

        public SetupService(UnitofWork uow)
        {
            _uow = uow;
            _motorRepository = _uow.GetRepository<Motor>();
            _motorDTO = new EMotorDTO();
            _brandRepository = _uow.GetRepository<Brand>();
            _brandDTO = new EBrandDTO();
            _fuelRepository = _uow.GetRepository<Fuel>();
            _categoryRepository = _uow.GetRepository<Category>();
            _fuelDTO = new EFuelDTO();
        }

        //--------------------Motor işlemleri----------------------////////////////////
        public void MotorInsert(EMotorDTO gelen)
        {
            var mot = AutoMapper.Mapper.DynamicMap<Motor>(gelen);
            _motorRepository.Insert(mot);
            _uow.SaveChanges();
        }

        public List<EMotorDTO> GetAllMotor()
        {
            var li = (from m in _motorRepository.GetAll()
                      orderby m.MotorType ascending
                      select new EMotorDTO
                      {
                          ID = m.ID,
                          MotorType = m.MotorType
                      }).ToList();

            return li;
        }


        public EMotorDTO MotorBul(int ID)
        {
            return (from m in _motorRepository.GetAll()
                    where m.ID == ID
                    select new EMotorDTO
                    {
                        ID = m.ID,
                        MotorType = m.MotorType
                    }).SingleOrDefault();
        }

        public void MotorUpdate(EMotorDTO gelen)
        {
            var mot = _motorRepository.Find(gelen.ID);
            AutoMapper.Mapper.DynamicMap(gelen, mot);
            _motorRepository.Update(mot);
            _uow.SaveChanges();

        }
        //--------------------Marka İşlemleri--------------------/////////////////
        public void BrandInsert(EBrandDTO gelen)
        {
            var brand = AutoMapper.Mapper.DynamicMap<Brand>(gelen);
            _brandRepository.Insert(brand);
            _uow.SaveChanges();
        }
        public List<EBrandDTO> GetAllBrand()
        {
            var li = (from b in _brandRepository.GetAll()
                      orderby b.BrandName ascending
                      select new EBrandDTO
                      {
                          ID = b.ID,
                          BrandName = b.BrandName
                      }).ToList();
            return li;
        }



        public EBrandDTO BrandBul(int ID)
        {
            var bulunan = _brandRepository.GetAll().Where(x => x.ID == ID).SingleOrDefault();
            EBrandDTO brand = new EBrandDTO()
            {
                ID = bulunan.ID,
                BrandName = bulunan.BrandName
            };
            return brand;

        }

        public void BrandUpdate(EBrandDTO gelen)
        {
            var brand = _brandRepository.Find(gelen.ID);
            AutoMapper.Mapper.DynamicMap(gelen, brand);
            _brandRepository.Update(brand);
            _uow.SaveChanges();
        }

        //---------------Yakıt Tipi işlemleri-------------------------------//
        public List<EFuelDTO> GetAllFuel()
        {
            var bulunan = (from f in _fuelRepository.GetAll()
                           select new EFuelDTO
                           {
                               ID = f.ID,
                               FuelType = f.FuelType
                           }).ToList();
            return bulunan;
        }
        public EFuelDTO FuelBul(int? ID)
        {

            var bulunan = _fuelRepository.Find((int)ID);
            EFuelDTO f = new EFuelDTO()
            {
                FuelType = bulunan.FuelType,
                ID = bulunan.ID

            };
            return f;

        }

        public void FuelUpdate(EFuelDTO gelen)
        {
            var fuel = _fuelRepository.Find(gelen.ID);
            AutoMapper.Mapper.DynamicMap(gelen, fuel);
            _fuelRepository.Update(fuel);
            _uow.SaveChanges();
        }

        //-------------------------------kategori İşlemleri----------------//

        public List<ECategoryDTO> KategoriListele()
        {
            //List<ECategoryDTO> li = new List<ECategoryDTO>();

            //List<Category> cat = _categoryRepository.GetAll().ToList();
            //foreach (var item in cat)
            //{
            //    ECategoryDTO cate = new ECategoryDTO()
            //    {
            //        CategoryName = item.CategoryName,
            //        ID = item.ID,
            //    };
            //    li.Add(cate);
            //}
            //return li;

            return ((from c in _categoryRepository.GetAll()
                     select new ECategoryDTO
                     {
                         CategoryName = c.CategoryName,
                         ID = c.ID
                     }).ToList()
                     );
        }
        public void KategoriEkle(ECategoryDTO gelen)
        {
            var ekle = AutoMapper.Mapper.DynamicMap<Category>(gelen);
            _categoryRepository.Insert(ekle);
            _uow.SaveChanges();
        }
    }
}
