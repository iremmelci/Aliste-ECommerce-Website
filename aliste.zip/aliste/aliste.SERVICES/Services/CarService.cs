﻿using aliste.CORE.Entities;
using aliste.DATA.GenericRepository;
using aliste.DATA.UnitofWork;
using aliste.DTO.EEntity;
using aliste.SERVICES.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.SERVICES.Services
{
    public class CarService : ICarService
    {
        private readonly IGenericRepository<Product> _productService;
        private readonly IUnitofWork _uow;
        private readonly IGenericRepository<Motor> _motorService;
        private readonly IGenericRepository<Fuel> _fuelService;
        private readonly IGenericRepository<aliste.CORE.Entities.Type> _typeService;
        private readonly IGenericRepository<Category> _categoryService;
        private readonly IGenericRepository<Brand> _brandService;

        public CarService(UnitofWork uow)
        {
            _uow = uow;
            _productService = _uow.GetRepository<Product>();
            _categoryService = _uow.GetRepository<Category>();
            _brandService = _uow.GetRepository<Brand>();
            _typeService = _uow.GetRepository<aliste.CORE.Entities.Type>();
            _fuelService = _uow.GetRepository<Fuel>();
            _motorService = _uow.GetRepository<Motor>();

        }

        public List<EProductListDTO> GetAllProduct()
        {
            
            var li = (from p in _productService.GetAll()
                      join c in _categoryService.GetAll() on p.CategoryID equals c.ID
                      join b in _brandService.GetAll() on p.BrandID equals b.ID
                      join t in _typeService.GetAll() on p.TypeID equals t.ID
                      join f in _fuelService.GetAll() on p.FuelID equals f.ID
                      join m in _motorService.GetAll() on p.MotorID equals m.ID
                      orderby p.ID descending
                      select new EProductListDTO
                      {
                          
                          ID = p.ID,
                          Color = p.Color,
                          Description = p.Description,
                          MaxPrice = p.MaxPrice,
                          MinPrice = p.MinPrice,
                          ProductionDate = p.ProductionDate,
                          ShiftType = p.ShiftType,
                          Title = p.Title,
                          BrandName = b.BrandName,
                          CategoryName = c.CategoryName,
                          MotorType = m.MotorType,
                          FuelType = f.FuelType,
                          TypeName = t.TypeName
                      }).ToList();

            foreach (var item in li)
            {
                item.Age = Convert.ToString(DateTime.Now.Year - item.ProductionDate.Year);
            }
            return li;
        }


    }
}
