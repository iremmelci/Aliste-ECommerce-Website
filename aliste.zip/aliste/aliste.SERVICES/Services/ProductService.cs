﻿using aliste.CORE.Entities;
using aliste.DATA.GenericRepository;
using aliste.DATA.UnitofWork;
using aliste.DTO.EEntity;
using aliste.SERVICES.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.SERVICES.Services
{
    public class ProductService : IProductService
    {
        private readonly IUnitofWork _uow;
        private readonly IGenericRepository<Product> _productRepository;
        private readonly IGenericRepository<Category> _categoryRepository;
        private readonly IGenericRepository<Motor> _motorRepository;
        private readonly IGenericRepository<Brand> _brandRepository;
        private readonly IGenericRepository<Fuel> _fuelRepository;
        private readonly IGenericRepository<CORE.Entities.Type> _typeRepository;

        public ProductService(IUnitofWork uow)
        {
            _uow = uow;
            _productRepository = _uow.GetRepository<Product>();
            _categoryRepository = _uow.GetRepository<Category>();
            _motorRepository = _uow.GetRepository<Motor>();
            _brandRepository = _uow.GetRepository<Brand>();
            _fuelRepository = _uow.GetRepository<Fuel>();
            _typeRepository = _uow.GetRepository<CORE.Entities.Type>();

        }

        public List<EProductListDTO> UrunListele()
        {
            var cat = _categoryRepository.GetAll();
            var mot = _motorRepository.GetAll();
            var bra = _brandRepository.GetAll();
            var fuel = _fuelRepository.GetAll();
            var typ = _typeRepository.GetAll();
            var li = (from p in _productRepository.GetAll()
                      //join c in cat on p.CategoryID equals c.ID
                      join m in mot on p.MotorID equals m.ID
                      join b in bra on p.BrandID equals b.ID
                      join f in fuel on p.FuelID equals f.ID
                      join t in typ on p.TypeID equals t.ID
                      select new EProductListDTO
                      {
                          ID = p.ID,
                          BrandName = b.BrandName,
                          //CategoryName = c.CategoryName,
                          Color = p.Color,
                          Description = p.Description,
                          FuelType = f.FuelType,
                          MaxPrice = p.MaxPrice,
                          MinPrice = p.MinPrice,
                          MotorType = m.MotorType,
                          ShiftType = p.ShiftType,
                          Title = p.Title,
                          TypeName = t.TypeName,
                      }).ToList();
            foreach (var item in li)
            {
                item.Age = Convert.ToString(DateTime.Now.Year - item.ProductionDate.Year);
            }
            return li;
        }


    }
}
