using aliste.CORE.Entities;
using aliste.DATA.GenericRepository;
using aliste.DATA.UnitofWork;
using aliste.SERVICES.Interface;
using aliste.SERVICES.Services;
using System.Web.Mvc;
using Unity;
using Unity.Lifetime;
using Unity.Mvc5;

namespace aliste.IoC
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new UnityContainer();
            RegisterTypes(container);
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }

        public static void RegisterTypes(IUnityContainer container)
        {
            container.BindInRequestScope<IUnitofWork, UnitofWork>();
            container.BindInRequestScope<IGenericRepository<Admin>, GenericRepository<Admin>>();
            container.BindInRequestScope<IGenericRepository<User>, GenericRepository<User>>();
            container.BindInRequestScope<IGenericRepository<Product>, GenericRepository<Product>>();
            container.BindInRequestScope<IGenericRepository<Fuel>, GenericRepository<Fuel>>();
            container.BindInRequestScope<IGenericRepository<Motor>, GenericRepository<Motor>>();
            container.BindInRequestScope<IGenericRepository<Type>, GenericRepository<Type>>();
            container.BindInRequestScope<IGenericRepository<Brand>, GenericRepository<Brand>>();
            container.BindInRequestScope<IGenericRepository<Category>, GenericRepository<Category>>();
            container.BindInRequestScope<IUserService, UserService>();
            container.BindInRequestScope<ICarService, CarService>();
            container.BindInRequestScope<ISetupService, SetupService>();
            container.BindInRequestScope<IProductService, ProductService>();


        }

        public static void BindInRequestScope<T1, T2>(this IUnityContainer container) where T2 : T1
        {
            container.RegisterType<T1, T2>(new HierarchicalLifetimeManager());
        }
    }
}