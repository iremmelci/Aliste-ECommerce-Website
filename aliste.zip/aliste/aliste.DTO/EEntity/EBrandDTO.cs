﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.DTO.EEntity
{
    public class EBrandDTO
    {
        public int ID { get; set; }
        public string BrandName { get; set; }
    }
}
