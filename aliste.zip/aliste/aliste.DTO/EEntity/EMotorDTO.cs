﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.DTO.EEntity
{
    public class EMotorDTO
    {
        public int ID { get; set; }
        public string MotorType { get; set; }


    }
}
