﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aliste.DTO.EEntity
{
    public class EProductListDTO
    {
        public int ID { get; set; }
        public string CategoryName { get; set; }
        public string MotorType { get; set; }
        public string TypeName { get; set; }
        public string BrandName { get; set; }
        public string FuelType { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Color { get; set; }
        public string ShiftType { get; set; }
        public DateTime ProductionDate { get; set; }
        public double MaxPrice { get; set; }
        public double MinPrice { get; set; }
        public string Age { get; set; }


    }
}
